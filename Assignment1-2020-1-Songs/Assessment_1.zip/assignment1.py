"""
Songs To Learn 1.0 - CP1404 - Assessment 1
Name: YangYang Li
Date started: 30/03/2020
GitHub URL: (private) https://github.com/cp1404-students/a1-yangyangli714
"""

import csv
# song_list = []


def open_file():
    """
    Opens the file
    """
    song_list = []
    file = open("songs.csv", "r")
    for lines in file.readlines():
        lines = lines.strip("\n")
        lines = lines.split(",")
        song_list.append(lines)
    file.close()
    return song_list


def valid_input(menu_selection):
    """
    Test the input
    """
    while menu_selection != "L" and menu_selection != "A" and menu_selection != "C" and menu_selection != "Q":
        print("Invalid menu menu_selection")
        print("Menu :")
        print("L - List songs\nA - Add new song\nC - Complete a song\nQ - Quit")
        menu_selection = input(">>>")
        menu_selection = menu_selection.upper()
    return menu_selection


def list_songs(song_list):
    """
    List of all the songs
    """
    not_learned_songs = 0
    learned_songs = 0
    for index, data in enumerate(song_list):
        if data[3] == "u":
            print(index, "* {:40s} - {:30s} ({})".format(data[0], data[1], data[2]))
            not_learned_songs = not_learned_songs + 1
        else:
            print(index, "  {:40s} - {:30s} ({})".format(data[0], data[1], data[2]))
            learned_songs = learned_songs + 1
    print("{} songs learned, {} songs still need to learn."
          .format(learned_songs, not_learned_songs))


def add_new_song(song_list):
    """
    Adds a new song to the list
    """
    title = str(input("Title: "))
    while title == "":
        print("Input cannot be blank.")
        title = str(input("Title: "))

    artist = str(input("Artist: "))
    while artist == "":
        print("Input cannot be blank.")
        artist = str(input("Artist: "))

    while True:
        try:
            year = int(input("Year: "))
            if year <= 0:
                print("Numbers must be > 0.")
            else:
                break
        except ValueError:
            print("Invalid input; Enter valid numbers")

    new_song = [title, artist, year, "u"]
    print("{} by {} ({}) added to song list".format(title, artist, year))
    song_list.append(new_song)


def complete_a_song(song_list):
    """
    Changes the status of a song in the list
    """
    completed_song = 0
    for complete in song_list:
        if complete[3] == "u":
            completed_song = completed_song - 1
    if completed_song != 0:
        while True:
            try:
                song_learned = int(input("Enter a number of the song "
                                         "to mark as learned: "))
                if song_learned < 0:
                    print("Number must be >= 0")
                elif song_learned > len(song_list):
                    print("Song number not in the list. The list goes up to {}"
                          .format(len(song_list) - 1))
                else:
                    break
            except ValueError:
                print("Invalid input; Enter a valid number")
        for index, data in enumerate(song_list):
            if index == song_learned:
                if data[3] == "u":
                    data[3] = "l"
                    print("{} by {} learned.".format(data[0], data[1]))
                else:
                    print("You have already learned {}".format(data[0]))
    else:
        print("No more songs to learn!")


def quit_program(song_list):
    """
    Quit the program
    """
    open_file = open("songs.csv", "w", newline="")
    writer = csv.writer(open_file, delimiter=",")
    for lines in song_list:
        writer.writerow(lines)
    open_file.close()
    print(len(song_list), "songs saved to songs.csv"
                          "\n Have a nice day!")


def main():
    """
    Include all other functions
    """
    print("-------------Songs To Learn 1.0 - by YangYang Li-------------")
    song_list = open_file()
    print(len(song_list), "song loaded")
    while True:
        print("Menu:\n    L - List songs\n    A - Add new song"
              "\n    C - Complete a song\n    Q - Quit")
        menu_selection = input("Enter the Menu: ").upper()
        menu_selection = valid_input(menu_selection)
        if menu_selection == "L":
            list_songs(song_list)
        elif menu_selection == "C":
            complete_a_song(song_list)
        elif menu_selection == "A":
            add_new_song(song_list)
        elif menu_selection == "Q":
            quit_program(song_list)
            break
    print("Thank you, bye !")


if __name__ == '__main__':
    main()









